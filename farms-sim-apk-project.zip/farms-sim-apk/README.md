# Farms Sim: build the APK

Needs: Node.js 18+, JDK 17, Android Studio (with Android SDK).

1. npm install
2. npm run setup          (copies three.js into www/ so the app works offline)
3. npx cap add android
4. npx cap sync android
5. npx cap open android   -> in Android Studio: Build > Build APK(s)

Or from the command line: cd android && ./gradlew assembleDebug
APK ends up in android/app/build/outputs/apk/debug/app-debug.apk

For Play Store you need a signed release build (Build > Generate Signed Bundle / APK).
